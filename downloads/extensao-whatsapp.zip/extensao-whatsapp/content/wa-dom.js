// ===== DETECÇÃO DA CONVERSA ABERTA (somente LEITURA do DOM) =====
// Postura anti-ban: nada de clique, nada de envio, nada de automação — só ler o
// que o usuário já está vendo. O DOM do WhatsApp não tem contrato: tudo aqui é
// best-effort em camadas, com null-check em tudo; se falhar, o painel degrada
// para a busca manual (camada 4, no panel.js) — nunca quebra o WhatsApp.

const WA_DOM=(()=>{

  // Camada 1 — JID no data-id das mensagens ("false_5581...@c.us_HEX").
  // É o dado mais estável: independe de layout, funciona p/ contato salvo ou não.
  // "@g.us" = grupo; "@lid" = privacidade de número (sem telefone visível) → cai
  // pras camadas seguintes.
  function jidFromMessages(main){
    const nodes=main.querySelectorAll('[data-id*="@c.us"],[data-id*="@g.us"],[data-id*="@lid"]');
    let lid=null;
    for(let i=nodes.length-1;i>=0;i--){
      const m=/(?:true|false)_(\d+)@(c\.us|g\.us|lid)/.exec(nodes[i].getAttribute('data-id')||'');
      if(!m) continue;
      if(m[2]==='lid'){ if(!lid) lid=m[1]; continue; }   /* 2.4: @lid não é telefone, mas é um ID FIXO da conversa */
      return {digits:m[1],isGroup:m[2]==='g.us'};
    }
    return lid?{lid}:null;
  }

  // Camada 2/3 — header do chat: título é o nome do contato salvo, ou o próprio
  // número formatado ("+55 81 9...") quando não salvo.
  function headerInfo(main){
    const header=main.querySelector('header');
    if(!header) return {name:null,phoneFromTitle:null};
    const el=header.querySelector('span[title]')||header.querySelector('span[dir="auto"]');
    const t=(el&&(el.getAttribute('title')||el.textContent)||'').trim();
    if(!t) return {name:null,phoneFromTitle:null};
    if(/^\+?[\d\s().-]{8,}$/.test(t)) return {name:null,phoneFromTitle:t};
    return {name:t,phoneFromTitle:null};
  }

  // Camada 2.5 — painel "Dados do contato" aberto: o número aparece como texto
  // FORA do #main. Cobre os chats @lid (WhatsApp esconde o telefone do JID por
  // privacidade): o usuário abre os dados do contato e o card resolve sozinho.
  function phoneFromDetailsPanel(main){
    // filtro GEOMÉTRICO: só o que está À DIREITA do #main (o drawer de dados).
    // Sem isso, contato não salvo na LISTA da esquerda (nome = número) seria
    // lido como telefone da conversa errada.
    const mr=main.getBoundingClientRect();
    const spans=document.querySelectorAll('span[dir="auto"], span.copyable-text');
    for(const el of spans){
      if(main.contains(el)) continue;
      const r=el.getBoundingClientRect();
      if(!r.width || r.left < mr.right-10) continue;
      const t=(el.textContent||'').replace(/ /g,' ').trim();
      if(/^\+?[\d\s().-]{10,20}$/.test(t)&&(t.match(/\d/g)||[]).length>=10) return t;
    }
    return null;
  }

  // -> {isGroup,phoneRaw,name,source:'jid'|'header'|'painel'|'nome'} | null (nenhum chat aberto)
  function getOpenChat(){
    const main=document.querySelector('#main');
    if(!main) return null;
    const {name,phoneFromTitle}=headerInfo(main);
    const jid=jidFromMessages(main);
    const lid=jid&&jid.lid?jid.lid:null;
    if(jid&&jid.isGroup) return {isGroup:true,name:name||'Grupo',phoneRaw:null,source:'jid'};
    if(jid&&jid.digits) return {isGroup:false,phoneRaw:jid.digits,name,lid,source:'jid'};
    if(phoneFromTitle) return {isGroup:false,phoneRaw:phoneFromTitle,name:null,lid,source:'header'};
    const det=phoneFromDetailsPanel(main);
    if(det) return {isGroup:false,phoneRaw:det,name,lid,source:'painel'};
    if(name||lid) return {isGroup:false,phoneRaw:null,name,lid,source:'nome'};
    return null;
  }

  // Observa troca de conversa: MutationObserver amplo + debounce; só notifica
  // quando a "assinatura" (telefone|nome) do chat aberto muda de fato.
  function observe(cb){
    let last='__init__', timer=null;
    const check=()=>{
      timer=null;
      const c=getOpenChat();
      const sig=c?`${c.isGroup?'g':'c'}|${c.phoneRaw||''}|${c.name||''}|${c.lid||''}`:'';
      if(sig!==last){ last=sig; try{ cb(c); }catch(_){} }
    };
    const mo=new MutationObserver(()=>{ if(!timer) timer=setTimeout(check,300); });
    mo.observe(document.body,{childList:true,subtree:true});
    check();
    return mo;
  }

  // Escreve `text` na caixa de mensagem do WhatsApp (compositor contenteditable).
  // NÃO envia — o usuário revisa e aperta Enter (anti-ban: sem automação de envio).
  // execCommand insertText é o que o editor do WhatsApp (Lexical/React) reconhece —
  // setar textContent direto é ignorado pelo framework.
  function fillComposer(text){
    const box=document.querySelector('#main footer div[contenteditable="true"][role="textbox"]')
           || document.querySelector('#main footer div[contenteditable="true"]')
           || document.querySelector('footer div[contenteditable="true"]');
    if(!box) return false;
    try{
      box.focus();
      document.execCommand('selectAll',false,null);
      const okDel=document.execCommand('insertText',false,text);
      if(okDel) return true;
    }catch(_){}
    // fallback: dispara beforeinput/input com o texto (alguns builds aceitam)
    try{
      box.focus();
      box.dispatchEvent(new InputEvent('beforeinput',{inputType:'insertText',data:text,bubbles:true,cancelable:true}));
      box.dispatchEvent(new InputEvent('input',{inputType:'insertText',data:text,bubbles:true}));
      return (box.textContent||'').includes(text.slice(0,8));
    }catch(_){ return false; }
  }

  return {getOpenChat,observe,fillComposer};
})();
