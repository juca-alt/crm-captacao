// ===== CRM API — CHOKE POINT DA EXTENSÃO =====
// ÚNICO arquivo que fala com /rest/v1/leads (o guard-choke-point.mjs verifica isso).
// Espelha os choke points do app: insertLead (index.html L1455), updateLead (L1413),
// logEdit (L3371), setLeadTask (L1408). Roda SOMENTE no service worker.
// Regra de fidelidade: derivados recalculados aqui, codigo VAZIO (trigger do banco
// numera o PI), etapa NUNCA gravada (derivada do status, só em memória no app).

const SESSION_KEY='wa_crm_session';

// ---------- sessão / auth (GoTrue via REST) ----------
async function getSession(){
  const o=await chrome.storage.local.get(SESSION_KEY);
  return o[SESSION_KEY]||null;
}
async function setSession(s){ await chrome.storage.local.set({[SESSION_KEY]:s}); }
async function clearSession(){ await chrome.storage.local.remove(SESSION_KEY); }

function sessionFromTokenResponse(data){
  const u=data.user||{};
  return {
    access_token:data.access_token,
    refresh_token:data.refresh_token,
    expires_at:data.expires_at||(Math.floor(Date.now()/1000)+(data.expires_in||3600)),
    user_email:u.email||'',
    // mesma régua do app (index.html L4555): ME = nome do metadata ou email, minúsculo
    usuario:((u.user_metadata&&u.user_metadata.nome)||u.email||'').toLowerCase()
  };
}

async function login(email,password){
  const r=await fetch(`${SB_URL}/auth/v1/token?grant_type=password`,{
    method:'POST',
    headers:{apikey:SB_KEY,'Content-Type':'application/json'},
    body:JSON.stringify({email,password})
  });
  const data=await r.json().catch(()=>({}));
  if(!r.ok){
    const raw=data.error_description||data.msg||'';
    // GoTrue devolve "Invalid login credentials" — traduz; o resto passa como veio
    const msg=(/invalid login credentials/i.test(raw)||data.error_code==='invalid_credentials')
      ?'E-mail ou senha incorretos.':(raw||'Falha no login — tente de novo.');
    throw {code:'auth',message:msg};
  }
  const s=sessionFromTokenResponse(data);
  await setSession(s);
  return {email:s.user_email,usuario:s.usuario};
}

async function logout(){
  const s=await getSession();
  if(s){ try{ await fetch(`${SB_URL}/auth/v1/logout`,{method:'POST',headers:{apikey:SB_KEY,Authorization:`Bearer ${s.access_token}`}}); }catch(_){} }
  await clearSession();
}

// refresh com promise única em voo — evita corrida de 2 abas do WhatsApp rotacionando
// o refresh token duas vezes (GoTrue invalida o antigo a cada uso)
let _refreshing=null;
async function refreshSession(s){
  if(_refreshing) return _refreshing;
  _refreshing=(async()=>{
    try{
      const r=await fetch(`${SB_URL}/auth/v1/token?grant_type=refresh_token`,{
        method:'POST',
        headers:{apikey:SB_KEY,'Content-Type':'application/json'},
        body:JSON.stringify({refresh_token:s.refresh_token})
      });
      const data=await r.json().catch(()=>({}));
      if(!r.ok){ await clearSession(); throw {code:'auth',message:'Sessão expirou — entre de novo.'}; }
      const ns=sessionFromTokenResponse(data);
      await setSession(ns);
      return ns;
    } finally { _refreshing=null; }
  })();
  return _refreshing;
}

async function freshSession(){
  let s=await getSession();
  if(!s) throw {code:'auth',message:'Não conectado ao CRM.'};
  if((s.expires_at||0)-60 < Math.floor(Date.now()/1000)) s=await refreshSession(s);
  return s;
}

// fetch autenticado no Supabase; 401 → tenta refresh uma vez e repete
async function sbFetch(path,opts){
  opts=opts||{};
  let s=await freshSession();
  const doFetch=(tok)=>fetch(`${SB_URL}${path}`,{
    method:opts.method||'GET',
    headers:Object.assign({apikey:SB_KEY,Authorization:`Bearer ${tok}`,'Content-Type':'application/json'},opts.headers||{}),
    body:opts.body!=null?JSON.stringify(opts.body):undefined
  });
  let r=await doFetch(s.access_token);
  if(r.status===401){ s=await refreshSession(s); r=await doFetch(s.access_token); }
  return r;
}

async function sbJson(path,opts){
  const r=await sbFetch(path,opts);
  const text=await r.text();
  let data=null; try{ data=text?JSON.parse(text):null; }catch(_){ data=null; }
  if(!r.ok) throw {code:(data&&data.code)||String(r.status),message:(data&&(data.message||data.msg))||`HTTP ${r.status}`,details:(data&&data.details)||'',status:r.status};
  return data;
}

// ---------- leitura ----------
const LEAD_COLS='id,codigo,nome,primeiro_nome,cargo,empresa,segmento,cidade,bairro,renda_estimada,faixa_idade,sexo,telefone,telefone_e164,email,linkedin_url,instagram_handle,observacoes,recomendante,origem,responsavel,score,prioridade,status,etapa,data_proxima_acao,data_status_atual,atualizado_em';

async function findByPhone(rawPhone){
  const vars=phoneE164Variants(rawPhone);
  if(!vars.length) return [];
  const list=vars.map(v=>`"${v}"`).join(',');
  return await sbJson(`/rest/v1/leads?select=${LEAD_COLS}&telefone_e164=in.(${encodeURIComponent(list)})&limit=5`);
}

async function searchByName(q){
  q=String(q||'').trim();
  if(!q) return [];
  // busca por telefone se o texto parecer número; senão ilike no nome
  if(/^[+\d][\d\s().-]{5,}$/.test(q)){
    const byTel=await findByPhone(q);
    if(byTel.length) return byTel;
  }
  const pat=encodeURIComponent('*'+q.replace(/[%*]/g,'')+'*');
  return await sbJson(`/rest/v1/leads?select=${LEAD_COLS}&nome=ilike.${pat}&order=atualizado_em.desc.nullslast&limit=10`);
}

// Busca por nome tolerante às tags do WhatsApp ("OT Fulano Rec LP Daniel"):
// consulta por CADA token (or=ilike) e ranqueia; strong = único candidato cujo
// primeiro+último nome estão contidos no apelido do chat.
async function findByName(nameRaw){
  const toks=nameTokens(nomePessoaDoChat(nameRaw)).slice(0,6);   /* 2.7.0: sem o "Rec Fulano" */
  if(!toks.length) return {strong:null,sugestoes:[]};
  const ors=toks.map(t=>`nome.ilike.*${t.replace(/[%*,()"]/g,'')}*`).join(',');
  let rows=[];
  try{ rows=await sbJson(`/rest/v1/leads?select=${LEAD_COLS}&or=${encodeURIComponent('('+ors+')')}&limit=15`); }
  catch(e){ if(e.code==='auth') throw e; rows=[]; }
  const set=new Set(toks);
  const scored=rows.map(l=>{
    const lt=nameTokens(l.nome||''); const hit=lt.filter(t=>set.has(t)).length;
    return {l,cov:lt.length?hit/lt.length:0,strong:nameStrongMatch(nameRaw,l.nome)};
  }).filter(x=>x.cov>0).sort((a,b)=>(b.strong-a.strong)||(b.cov-a.cov));
  const strongs=scored.filter(x=>x.strong);
  return {strong:strongs.length===1?strongs[0].l:null, sugestoes:scored.slice(0,5).map(x=>x.l)};
}

async function findByEmail(email){
  const e=normEmail(email);
  if(!e) return [];
  return await sbJson(`/rest/v1/leads?select=${LEAD_COLS}&email=ilike.${encodeURIComponent(e)}&limit=2`);
}

// modelos de mensagem do CRM (Configurações → Modelos); default = MSG_TPL_DEFAULT
async function getMsgTemplates(){
  try{
    const rows=await sbJson(`/rest/v1/app_settings?select=valor&chave=eq.msg_templates&limit=1`);
    if(rows&&rows[0]&&rows[0].valor){ const a=JSON.parse(rows[0].valor); if(Array.isArray(a)&&a.length) return a; }
  }catch(_){ /* sem acesso/tabela → default */ }
  return MSG_TPL_DEFAULT;
}
// grava os modelos no MESMO lugar do app (app_settings.msg_templates) — o CRM lê no
// próximo load; upsert por chave, igual ao saveSetting do index.html (L1396).
async function saveMsgTemplates(arr){
  await sbJson(`/rest/v1/app_settings?on_conflict=chave`,{method:'POST',
    body:{chave:'msg_templates',valor:JSON.stringify(arr||[]),atualizado_em:new Date().toISOString()},
    headers:{Prefer:'resolution=merge-duplicates,return=minimal'}});
  return true;
}

async function getFunilCfg(){
  try{
    const rows=await sbJson(`/rest/v1/app_settings?select=valor&chave=eq.funil_cfg&limit=1`);
    if(rows&&rows[0]&&rows[0].valor){ const c=JSON.parse(rows[0].valor); if(c&&Array.isArray(c.etapas)&&c.etapas.length) return c; }
  }catch(_){ /* sem acesso/tabela → default */ }
  return null;
}

// ---------- log de atividade (espelho de logEdit L3370-3381) ----------
const EDIT_LABELS={nome:'Nome',cargo:'Cargo',empresa:'Empresa',segmento:'Segmento',bairro:'Bairro',renda_estimada:'Renda',faixa_idade:'Idade',telefone:'Telefone',sexo:'Sexo',status:'Status',data_proxima_acao:'Follow-up',agendamento:'Agendamento',linkedin_url:'LinkedIn',instagram_handle:'Instagram',observacoes:'Observações',prioridade:'Prioridade',acompanhar_victor:'Acomp. Victor'};
async function logEdit(id,before,patch,usuario){
  before=before||{};
  const changed=[];
  for(const k in patch){ if(!(k in EDIT_LABELS))continue; const a=before[k]==null?'':String(before[k]), b=patch[k]==null?'':String(patch[k]); if(a!==b)changed.push(EDIT_LABELS[k]); }
  if(!changed.length)return;
  const stChg = patch.status!=null && String(before.status||'')!==String(patch.status);
  const row={lead_id:id,tipo:stChg?'status':'edicao',texto:'✏️ Editou: '+changed.join(', '),usuario:usuario||''};
  if(stChg) row.para_status=patch.status;
  try{ await sbJson('/rest/v1/lead_events',{method:'POST',body:row,headers:{Prefer:'return=minimal'}}); }catch(_){ /* fire-and-forget, igual ao app */ }
}

// ---------- escrita ----------
// tradução do 23505 (UNIQUE) — mesma régua do insertLead L1473-1483
function dupKeyFrom23505(details){
  const d=String(details||'');
  if(/codigo/i.test(d)&&!/linkedin|instagram|telefone|e164|email/i.test(d)) return null; // colisão de PI, não é lead duplicado
  return /instagram/i.test(d)?'instagram':/linkedin/i.test(d)?'linkedin':/telefone|e164/i.test(d)?'telefone':/email/i.test(d)?'email':'telefone';
}

// espelho de updateLead (L1413-1444): derivados + carimbos + log; NUNCA grava etapa
async function waUpdateLead(id,patch,before){
  before=before||{};
  patch=Object.assign({},patch);
  delete patch.etapa;
  if('nome' in patch && patch.nome) patch.primeiro_nome=firstName(patch.nome);
  if('telefone' in patch && !('telefone_e164' in patch)){ const p=normPhone(patch.telefone||''); patch.telefone=p.telefone; patch.telefone_e164=p.e164; }
  if('email' in patch && patch.email) patch.email=patch.email.trim()||null;
  if(patch.status==='Convite Enviado' && !before.convite_enviado_em && !('convite_enviado_em' in patch)) patch.convite_enviado_em=new Date().toISOString();
  if('status' in patch && patch.status!==before.status && !('data_status_atual' in patch)) patch.data_status_atual=new Date().toISOString();
  patch.atualizado_em=new Date().toISOString();
  let rows;
  try{
    rows=await sbJson(`/rest/v1/leads?id=eq.${encodeURIComponent(id)}&select=${LEAD_COLS}`,{method:'PATCH',body:patch,headers:{Prefer:'return=representation'}});
  }catch(e){
    if(e.code==='23505'){
      const key=dupKeyFrom23505(e.details||e.message);
      if(key===null) return {status:'error',message:'Colisão de código PI — recarregue o CRM e tente de novo.'};
      return {status:'error',message:'Esse telefone/e-mail já pertence a outro lead — verifique em Duplicatas no CRM.'};
    }
    if(e.code==='auth') throw e;
    if(/enum origem_t/i.test(e.message||'')){ const v=(/enum origem_t: "([^"]+)"/.exec(e.message||'')||[])[1]||'?'; return {status:'error',message:`Origem "${v}" não existe no banco — rode supabase/migrations/origem_whatsapp.sql (bloco completo) no SQL Editor.`}; }
    return {status:'error',message:e.message||'falha ao salvar'};
  }
  const lead=rows&&rows[0];
  if(!lead) return {status:'error',message:'Lead não encontrado (pode ter sido removido).'};
  const s=await getSession();
  await logEdit(id,before,patch,s&&s.usuario);
  return {status:'updated',lead};
}

// espelho de insertLead (L1455-1493): derivados + dedupe pré-insert (server-side,
// por telefone/email — chaves fortes do canal WhatsApp) + codigo vazio (trigger PI)
async function waInsertLead(rec){
  rec=Object.assign({},rec);
  delete rec.etapa; delete rec.codigo;
  if(rec.nome) rec.primeiro_nome=firstName(rec.nome);
  if('telefone' in rec && !('telefone_e164' in rec)){ const p=normPhone(rec.telefone||''); rec.telefone=p.telefone; rec.telefone_e164=p.e164; }
  if(rec.email) rec.email=rec.email.trim()||null;
  if(rec.status==='Convite Enviado' && !rec.convite_enviado_em) rec.convite_enviado_em=new Date().toISOString();
  // dedupe ANTES do insert (só chaves fortes bloqueiam; nome nunca — igual ao app)
  if(rec.telefone_e164){
    const hit=await findByPhone(rec.telefone_e164);
    if(hit.length) return {status:'duplicate',key:'telefone',existing:hit[0]};
  }
  if(rec.email){
    const hit=await findByEmail(rec.email);
    if(hit.length) return {status:'duplicate',key:'email',existing:hit[0]};
  }
  let rows;
  try{
    rows=await sbJson(`/rest/v1/leads?select=${LEAD_COLS}`,{method:'POST',body:rec,headers:{Prefer:'return=representation'}});
  }catch(e){
    if(e.code==='23505'){
      const key=dupKeyFrom23505(e.details||e.message);
      if(key===null) return {status:'error',message:'colisão de código PI — recarregue e tente de novo',code:e.code};
      let existing=null;
      try{
        if(key==='telefone'&&rec.telefone_e164) existing=(await findByPhone(rec.telefone_e164))[0]||null;
        else if(key==='email'&&rec.email) existing=(await findByEmail(rec.email))[0]||null;
      }catch(_){}
      return {status:'duplicate',key,existing};
    }
    if(e.code==='auth') throw e;
    if(/enum origem_t/i.test(e.message||'')){ const v=(/enum origem_t: "([^"]+)"/.exec(e.message||'')||[])[1]||'?'; return {status:'error',message:`Origem "${v}" não existe no banco — rode supabase/migrations/origem_whatsapp.sql (bloco completo) no SQL Editor.`,code:e.code}; }
    return {status:'error',message:e.message||'falha ao criar lead',code:e.code};
  }
  const lead=rows&&rows[0];
  if(!lead) return {status:'error',message:'insert sem retorno — confira RLS/permissões no Supabase'};
  return {status:'created',lead};
}

// ---------- Visão LP · Carteira (leitura) ----------
// Contatos/funil da LP vivem no localStorage do vendas.html (fora do alcance);
// o que existe no Supabase é a CARTEIRA (carteira_clientes/carteira_apolices,
// jsonb, RLS por dono=email). Telefone fica solto dentro do jsonb → o match é
// client-side: extrai números do dados e compara nas variantes e164.
let _cartCache=null, _cartAt=0;
async function carteiraAll(force){
  if(!force && _cartCache && Date.now()-_cartAt<5*60*1000) return _cartCache;
  const clientes=await sbJson('/rest/v1/carteira_clientes?select=ref,dados,atualizado');
  let apolices=[];
  try{ apolices=await sbJson('/rest/v1/carteira_apolices?select=chave,dados'); }catch(_){}
  _cartCache={clientes:clientes||[],apolices:apolices||[]}; _cartAt=Date.now();
  return _cartCache;
}
function phonesFromJson(obj){
  const out=new Set();
  const txt=JSON.stringify(obj||{});
  for(const m of txt.matchAll(/\+?\d[\d\s().\/-]{7,}\d/g)){
    const e=normPhone(m[0]).e164; if(e) out.add(e);
  }
  return out;
}
/* 2.8.0: a apólice também casa pelo vínculo explícito do cockpit (dados.cli_ref = ref do cliente) */
function apolicesRowsDoCliente(cart,cli){
  const nome=normName((cli.dados&&cli.dados.nome)||cli.ref||''), ref=String(cli.ref||'');
  if(!nome&&!ref) return [];
  return cart.apolices.filter(a=>{ const d=a.dados||{}; if(ref&&d.cli_ref&&String(d.cli_ref)===ref) return true; return !!nome&&normName(JSON.stringify(d)).includes(nome); });
}
function apolicesDoCliente(cart,cli){ return apolicesRowsDoCliente(cart,cli).map(a=>a.chave); }
/* 2.8.0 (aba 👤 Perfil): resumo de cada apólice nos DOIS formatos da carteira (importador {apolice,periodicidade,status,premio}
   e cockpit {ap,period,mrr} — mesma régua do cartNormApolice do vendas.html). O número sai MASCARADO daqui (001…611):
   o painel nunca recebe o número inteiro. Sem status na carga = 'Ativa' presumido (é a carteira ativa), carimbado. */
function cartMoneyNum(v){ if(typeof v==='number') return isFinite(v)?v:0; const s=String(v==null?'':v).replace(/[^\d,.-]/g,''); if(!s) return 0;
  const n=/,\d{1,2}$/.test(s)?Number(s.replace(/\./g,'').replace(',','.')):Number(s.replace(/,/g,'')); return isFinite(n)?n:0; }
function numMascara(n){ const s=String(n||'').replace(/\s/g,''); if(!s) return ''; return s.length>6?s.slice(0,3)+'…'+s.slice(-3):'…'+s.slice(-3); }
function apoliceResumo(a){ const d=a.dados||{}; const num=d.apolice||d.ap||String(a.chave||'').split('|')[0]||d.proposta||'';
  return { num:numMascara(num), premio:cartMoneyNum(d.premio!=null?d.premio:d.mrr), periodicidade:d.periodicidade||d.period||'', forma:d.forma||'',
    status:d.status||'Ativa', statusPresumido:!d.status, produto:d.produto||d.plano||d.familia||'' }; }
function _cartCliOut(cart,c){ const d=c.dados||{}, rows=apolicesRowsDoCliente(cart,c), cob=(d.cob&&typeof d.cob==='object')?d.cob:null;
  return {ref:c.ref,dados:d,atualizado:c.atualizado,apolices:rows.map(a=>a.chave),aps:rows.map(apoliceResumo),
    cob:cob||{cs:cartMoneyNum(d.cap!=null?d.cap:d.cs),pm:cartMoneyNum(d.mrr!=null?d.mrr:d.pm),renda:cartMoneyNum(d.renda)},cobDetalhe:!!cob,
    nascimento:d.nascimento||d.nasc||null,idade:d.idade!=null?d.idade:null}; }
async function lpFindByPhone(rawPhone){
  const vars=new Set(phoneE164Variants(rawPhone));
  if(!vars.size) return [];
  const cart=await carteiraAll();
  return cart.clientes
    .filter(c=>{ const ph=phonesFromJson(c.dados); return [...vars].some(v=>ph.has(v)); })
    .map(c=>_cartCliOut(cart,c))
    .slice(0,5);
}
/* 2.8.0: o negócio achado mas a Carteira não bateu pelo telefone (número diferente no portal) → nome IGUAL (normalizado),
   só quando um único cliente tem esse nome. Nada de "parecido": é o chip "Cliente · N apólices" do cabeçalho. */
async function lpCarteiraPorNome(nome){
  const n=normName(nome||''); if(!n||n.split(' ').length<2) return [];
  const cart=await carteiraAll();
  const hit=cart.clientes.filter(c=>normName((c.dados&&c.dados.nome)||c.ref||'')===n);
  return hit.length===1?[_cartCliOut(cart,hit[0])]:[];
}
/* 2.8.0: Família da aba 👤 Perfil — carteira_perfil (PERFIL-DO-CLIENTE-V1 do app: cônjuge, filhos, outros, profissão, locais).
   1 GET pequeno, só quando o card mostra um cliente da Carteira. Sem tabela/permissão = sem bloco. */
async function cartPerfilGet(ref){
  ref=String(ref||''); if(!ref) return null;
  try{ const rows=await sbJson(`/rest/v1/carteira_perfil?select=dados&ref=eq.${encodeURIComponent(ref)}&limit=1`); return (rows&&rows[0]&&rows[0].dados)||null; }
  catch(e){ if(e.code==='auth') throw e; return null; }
}
async function lpSearch(q){
  q=normName(q||''); if(!q) return [];
  const cart=await carteiraAll();
  return cart.clientes
    .filter(c=>normName((c.dados&&c.dados.nome)||c.ref||'').includes(q))
    .map(c=>_cartCliOut(cart,c))
    .slice(0,10);
}

// ---------- Visão LP · Contatos/Funil (lp_contatos — sync do vendas.html v0.4.1+) ----------
// 1 linha por contato (dados jsonb = contato inteiro), RLS por dono. O vendas.html
// faz merge por `_upd` (maior vence) — toda escrita daqui carimba dados._upd.
/* 2.2 (28/09): CACHE-GERACAO-V1. Antes, uma leitura que SAÍA antes de uma gravação e CHEGAVA depois dela (o GET
   de toda a tabela leva segundos: ~5 mil linhas com o Estoque) regravava o cache com a foto VELHA por 2 min — voltar
   à conversa mostrava o card sem a mudança ("não salvou"). Agora: toda gravação sobe a geração e troca a linha no
   cache na hora; leitura de geração velha não entra no cache; leituras simultâneas viram uma só. */
let _lpcCache=null, _lpcAt=0, _lpcGen=0, _lpcVoo=null;
async function lpcAll(force){
  if(!force && _lpcCache && Date.now()-_lpcAt<2*60*1000) return _lpcCache;
  if(!force && _lpcVoo) return _lpcVoo;
  const gen=_lpcGen;
  const voo=(async()=>{
    let rows;
    try{ rows=await sbJson('/rest/v1/lp_contatos?select=id,dados,atualizado')||[]; }
    catch(e){ if(e.code==='auth') throw e; rows=[]; /* tabela ainda não criada → trata como vazia */ }
    if(gen===_lpcGen){ _lpcCache=rows; _lpcAt=Date.now(); }
    return rows;
  })();
  _lpcVoo=voo;
  try{ return await voo; } finally{ if(_lpcVoo===voo) _lpcVoo=null; }
}
/* gravou → a linha nova entra no cache já (sem baixar a tabela de novo) e qualquer leitura em voo vira velha */
function lpcCacheGravou(row){
  _lpcGen++; _lpcVoo=null;
  if(!_lpcCache||!row||row.id==null) return;
  const out={id:row.id,dados:row.dados,atualizado:row.atualizado};
  const i=_lpcCache.findIndex(r=>String(r.id)===String(row.id));
  if(i>=0) _lpcCache[i]=out; else _lpcCache.push(out);
}
/* o card mostra a linha FRESCA do banco, nunca só a do cache (o app/outro aparelho pode ter mudado nesse meio-tempo) */
async function lpcFrescos(lista){
  const ids=[...new Set((lista||[]).filter(Boolean).map(r=>String(r.id)))];
  if(!ids.length) return lista;
  let rows=[];
  try{ rows=await sbJson(`/rest/v1/lp_contatos?id=in.(${ids.map(i=>'"'+i.replace(/"/g,'')+'"').map(encodeURIComponent).join(',')})&select=id,dados,atualizado`)||[]; }
  catch(e){ if(e.code==='auth') throw e; return lista; }
  const por={}; rows.forEach(r=>{ por[String(r.id)]=r; });
  return lista.map(r=>{ const f=r&&por[String(r.id)]; if(!f) return r; if(_lpcCache){ const i=_lpcCache.findIndex(x=>String(x.id)===String(f.id)); if(i>=0) _lpcCache[i]=_lpcOut(f); } return Object.assign({},r,_lpcOut(f)); });
}
function _lpcOut(r){ return {id:r.id,dados:r.dados,atualizado:r.atualizado}; }
/* v2.0: o Estoque (funil 'bn') mora na mesma tabela — separado do funil pra um nome do Estoque nunca virar negócio ao salvar */
function _lpcEhBn(r){ return !!(r&&r.dados&&r.dados.funil==='bn'); }
function _lpcTelHit(r,vars){ const d=r.dados||{}; const ph=phonesFromJson([d.telefone||''].concat(Array.isArray(d.telefones_alt)?d.telefones_alt:[]).join(' ')); return [...vars].some(v=>ph.has(v)); }
async function lpcFindByPhone(rawPhone){
  const vars=new Set(phoneE164Variants(rawPhone));
  if(!vars.size) return [];
  const rows=await lpcAll();
  return rows.filter(r=>!_lpcEhBn(r)&&_lpcTelHit(r,vars)).map(_lpcOut).slice(0,5);
}
async function lpcEstoqueByPhone(rawPhone){
  const vars=new Set(phoneE164Variants(rawPhone)); if(!vars.size) return [];
  const rows=await lpcAll(); return rows.filter(r=>_lpcEhBn(r)&&_lpcTelHit(r,vars)).map(_lpcOut).slice(0,3);
}
async function lpcSearch(q){
  q=normName(q||''); if(!q) return [];
  const rows=await lpcAll();
  return rows.filter(r=>!_lpcEhBn(r)&&normName((r.dados&&r.dados.nome)||'').includes(q)).map(_lpcOut).slice(0,10);
}
async function lpcSave(id,dados){
  // shape canônico ANTES de gravar (lpcNormContato, normalize.js). O app tem o
  // normContato() como rede de segurança, mas contato incompleto no banco volta
  // incompleto a cada edição — normalizar no choke point fecha o ciclo na origem.
  dados=lpcNormContato(Object.assign({},dados));
  if(dados.id==null) dados.id=String(id);
  dados._upd=new Date().toISOString();
  const rows=await sbJson(`/rest/v1/lp_contatos?on_conflict=dono,id&select=id,dados,atualizado`,
    {method:'POST',body:{id:String(id),dados},headers:{Prefer:'resolution=merge-duplicates,return=representation'}});
  const saiu=rows&&rows[0]?_lpcOut(rows[0]):{id:String(id),dados};
  lpcCacheGravou(saiu);
  return saiu;
}
async function lpcFindByName(nameRaw){
  const toks=nameTokens(nomePessoaDoChat(nameRaw));   /* 2.7.0: sem o "Rec Fulano" — quem indicou não é a pessoa */
  if(!toks.length) return {strong:null,sugestoes:[]};
  const set=new Set(toks);
  const rows=(await lpcAll()).filter(r=>!_lpcEhBn(r));
  const scored=rows.map(r=>{
    const n=(r.dados&&r.dados.nome)||'';
    const lt=nameTokens(n); const hit=lt.filter(t=>set.has(t)).length;
    return {r,cov:lt.length?hit/lt.length:0,strong:nameStrongMatch(nameRaw,n)};
  }).filter(x=>x.cov>0).sort((a,b)=>(b.strong-a.strong)||(b.cov-a.cov));
  const strongs=scored.filter(x=>x.strong);
  return {strong:strongs.length===1?_lpcOut(strongs[0].r):null, sugestoes:scored.slice(0,5).map(x=>_lpcOut(x.r))};
}

// visão combinada da LP: contatos do funil (prioridade) + Carteira; sem telefone
// (ou sem match por telefone), tenta o match forte por nome nos contatos
/* ===== 2.4: VÍNCULO conversa do WhatsApp ↔ negócio do CRM =====
   Pedido dele: "quando eu atrelar uma conversa do WhatsApp ao caso do CRM, ele reconhecer mais fácil — algum código id".
   O WhatsApp novo esconde o telefone (@lid) e o nome vem com etiquetas, então a busca às vezes erra. Ao ESCOLHER o
   negócio no card (ou criar), a extensão grava chave-da-conversa → id do negócio. Chaves: tel:<dígitos> · lid:<id fixo
   do WhatsApp> · nome:<nome do chat normalizado>. Na próxima vez o vínculo vence qualquer busca. */
function waNormNome(s){ return String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim(); }
async function vincTodos(){ try{ const o=await chrome.storage.local.get('wa_vinc'); return (o&&o.wa_vinc)||{}; }catch(_){ return {}; } }
async function vincDe(keys){ const v=await vincTodos(); for(const k of (keys||[])){ if(k&&v[k]) return v[k]; } return null; }
async function vincLocal(keys,id,nome){ const v=await vincTodos(); const x={id:String(id),nome:String(nome||''),ts:Date.now()};
  (keys||[]).filter(Boolean).forEach(k=>{ v[k]=x; }); await chrome.storage.local.set({wa_vinc:v}); }
/* 2.5: o vínculo também vai pro CADASTRO do negócio (dados.wa_chats) → vale em outro aparelho. Uma conversa = um
   negócio: se outro negócio tinha essas chaves, elas saem de lá. */
function _vincDonos(rows,keys,exceto){ const ks=new Set((keys||[]).map(String));
  return (rows||[]).filter(r=>String(r.id)!==String(exceto||'')&&Array.isArray(r.dados&&r.dados.wa_chats)&&r.dados.wa_chats.some(k=>ks.has(String(k)))); }
async function vincGravar(keys,id,nome){
  keys=(keys||[]).filter(Boolean); if(!keys.length||!id) return false;
  await vincLocal(keys,id,nome);
  await lpcPatch(id,[{tipo:'wa_vinc',add:keys}]);
  try{ const outros=_vincDonos(await lpcAll(),keys,id); for(const o of outros) await lpcPatch(o.id,[{tipo:'wa_desv',keys}]); }catch(_){}
  return true; }
async function vincTirar(keys,id){
  keys=(keys||[]).filter(Boolean); const v=await vincTodos(); keys.forEach(k=>{ delete v[k]; }); await chrome.storage.local.set({wa_vinc:v});
  try{ const alvo=new Set(id?[String(id)]:[]); _vincDonos(await lpcAll(),keys).forEach(r=>alvo.add(String(r.id)));
    for(const x of alvo) await lpcPatch(x,[{tipo:'wa_desv',keys}]); }catch(_){}
  return true; }
/* acha o negócio ligado: 1º o atalho local deste Chrome, depois o cadastro (dados.wa_chats) — outro aparelho */
async function vincAchar(keys){
  const vv=await vincDe(keys);
  if(vv){ const f=await lpcFrescos([{id:vv.id}]); const row=f&&f[0];
    if(row&&row.dados&&!Array.isArray(row.dados.wa_chats)){ lpcPatch(row.id,[{tipo:'wa_vinc',add:keys}]).catch(()=>{}); return row; }   /* vínculo da 2.4 (só local) sobe pro CRM */
    if(row&&row.dados&&row.dados.wa_chats.some(k=>keys.includes(String(k)))) return row; }
  const donos=_vincDonos(await lpcAll(),keys);
  if(!donos.length) return null;
  donos.sort((a,b)=>String((b.dados&&b.dados._upd)||'').localeCompare(String((a.dados&&a.dados._upd)||'')));
  const f=await lpcFrescos([donos[0]]); const row=(f&&f[0])||donos[0];
  try{ await vincLocal(keys,row.id,row.dados&&row.dados.nome); }catch(_){}
  return row; }
/* 2.6.0 MULTI-NEG: os negócios da MESMA pessoa (pessoaId) + as empresas do Vida em Grupo onde ela é contato
   (dados.pjContatos[].ct — VG-EMPRESA-V1 do CRM). Lê do cache (lpcAll); o card de cada um é relido ao abrir. */
async function lpNegocios(id){
  /* 2.6.1 (AUDIT H1, 01/10): UMA regra pra contato da empresa ↔ negócio de pessoa, igual à do CRM (pjContatoAlvos), nos dois sentidos:
     ct que existe → ele; sem ct (ou ct apagado) → telefone (se o telefone servir a mais de uma pessoa, só quem bate o nome);
     sem telefone (sem dígitos) → nome, só se o nome é de UMA pessoa. */
  const rows=(await lpcAll()).filter(r=>r&&r.dados&&!_lpcEhBn(r));
  const eu=rows.find(r=>String(r.id)===String(id)); if(!eu) return [];
  const ehEmp=r=>(r.dados.funil==='vg'||r.dados.funil==='vg-bc')&&Array.isArray(r.dados.pjContatos);
  const pess=rows.filter(r=>!ehEmp(r)), pk=r=>String(r.dados.pessoaId||r.id);
  const item=(r,papel,pessoa)=>({id:String(r.id),funil:r.dados.funil||'nn',etapa:r.dados.etapa||'',nome:r.dados.nome||'',papel:papel||null,pessoa:pessoa||null});
  const irmaosDe=r=>{ const pid=r.dados.pessoaId; return pid?rows.filter(x=>x.dados.pessoaId===pid):[r]; };
  const alvos=p=>{ if(!p) return [];
    if(p.ct){ const o=pess.find(r=>String(r.id)===String(p.ct)); if(o) return [o]; }
    const pv=new Set(String(p.tel||'').replace(/\D/g,'').length>=8?phoneE164Variants(p.tel):[]), nk=waNormNome(p.nome||'');   /* telefone com menos de 8 dígitos = sem telefone (igual ao CRM) */
    if(pv.size){ let a=pess.filter(r=>phoneE164Variants(r.dados.telefone||'').some(v=>pv.has(v)));
      if(new Set(a.map(pk)).size>1) a=a.filter(r=>waNormNome(r.dados.nome||'')===nk); return a; }
    if(!nk) return [];
    const a=pess.filter(r=>waNormNome(r.dados.nome||'')===nk); return new Set(a.map(pk)).size===1?a:[]; };
  const out=[], vistos=new Set(), add=(r,papel,pessoa)=>{ const k=String(r.id); if(vistos.has(k)) return; vistos.add(k); out.push(item(r,papel,pessoa)); };
  if(ehEmp(eu)){   /* ficha da EMPRESA: a empresa + os negócios de cada contato */
    add(eu,null);
    eu.dados.pjContatos.forEach(p=>alvos(p).forEach(a=>irmaosDe(a).forEach(r=>add(r,null,r.dados.nome||p.nome||''))));
    return out; }
  const irmaos=irmaosDe(eu), ids=new Set(irmaos.map(r=>String(r.id)));
  irmaos.forEach(r=>add(r,null));
  const casa=p=>alvos(p).some(a=>ids.has(String(a.id)));
  rows.forEach(r=>{ if(!ehEmp(r)||ids.has(String(r.id))) return; const l=r.dados.pjContatos;
    const x=l.find(p=>p&&p.ct&&ids.has(String(p.ct)))||l.find(p=>p&&casa(p));   /* ct direto passa na frente (papel certo) */
    if(x) add(r,x.papel||'outro'); });
  if(!vistos.has(String(id))) out.unshift(item(eu,null));
  return out;
}
async function lpcUm(id){ const f=await lpcFrescos([{id}]); if(f&&f[0]&&f[0].dados) return f[0]; return (await lpcAll()).find(r=>String(r.id)===String(id))||null; }
/* 2.8.0: Carteira do negócio achado — telefone do chat → telefone do cadastro → nome igual (ver lpCarteiraPorNome) */
async function _cartDoContato(rawPhone,row){
  let c=[]; try{ c=await lpFindByPhone(rawPhone); }catch(_){}
  const d=(row&&row.dados)||{};
  if(!c.length&&d.telefone) try{ c=await lpFindByPhone(d.telefone); }catch(_){}
  if(!c.length&&d.nome) try{ c=await lpCarteiraPorNome(d.nome); }catch(_){}
  return c;
}
async function lpLookup(rawPhone,chatName,keys){
  if(keys&&keys.length){ let row=null; try{ row=await vincAchar(keys); }catch(e){ if(e.code==='auth') throw e; }
    if(row&&row.dados){ const carteira=_lpcEhBn(row)?[]:await _cartDoContato(rawPhone,row);
      return _lpcEhBn(row)?{contatos:[],carteira,byName:null,estoque:[row],vinculo:true}:{contatos:[row],carteira,byName:null,estoque:[],vinculo:true}; } }
  const [contatos,carteira,estoque]=await Promise.all([lpcFindByPhone(rawPhone),lpFindByPhone(rawPhone),lpcEstoqueByPhone(rawPhone)]);
  let byName=null;
  if(!contatos.length&&chatName){ byName=await lpcFindByName(chatName); }
  /* só as linhas que VÃO pro card são relidas (1 GET pequeno) — o cache serve pra achar, não pra mostrar */
  const alvo=[...contatos,...estoque,...(byName&&byName.strong?[byName.strong]:[])];
  if(alvo.length){ const f=await lpcFrescos(alvo); const m={}; f.forEach(r=>{ m[String(r.id)]=r; });
    const troca=r=>(r&&m[String(r.id)])||r;
    const um=contatos.length===1?troca(contatos[0]):(!contatos.length&&byName&&byName.strong?troca(byName.strong):null);
    const cart=(!carteira.length&&um)?await _cartDoContato('',um):carteira;   /* 2.8.0: chip "Cliente" também pelo cadastro */
    return {contatos:contatos.map(troca),carteira:cart,byName:byName?Object.assign({},byName,{strong:troca(byName.strong)}):byName,estoque:estoque.map(troca)}; }
  return {contatos,carteira,byName,estoque};
}

// ---------- v2.0: configuração do funil do app + gravação segura por AÇÃO ----------
let _lpCfg=null, _lpCfgAt=0;
async function lpCfgGet(force){
  if(!force&&_lpCfg&&Date.now()-_lpCfgAt<60*1000) return _lpCfg;
  const rows=await sbJson(`/rest/v1/app_settings?select=chave,valor&chave=in.(lp_funil_cfg,lp_listas_ta)`);
  const m={}; (rows||[]).forEach(r=>{ let v=r.valor; if(typeof v==='string'){ try{ v=JSON.parse(v); }catch(_){} } m[r.chave]=v; });
  let listasUso=[]; try{ listasUso=await lpcAll(); }catch(e){ if(e.code==='auth') throw e; }
  _lpCfg={funil:(m.lp_funil_cfg&&typeof m.lp_funil_cfg==='object')?m.lp_funil_cfg:null, listas:lpcListasCatalogo(Array.isArray(m.lp_listas_ta)?m.lp_listas_ta:[],listasUso)};
  _lpCfgAt=Date.now(); return _lpCfg;
}
/* Relê a linha FRESCA (com o dono), aplica as ações sobre ela e grava só essa linha. Nunca manda uma cópia velha
   inteira: o que o app mudou nesse intervalo fica. O dono vai junto (Victor editando a base do Gustavo não cria cópia). */
async function lpcPatch(id,acoes){
  const s=await getSession(); const por=(s&&s.user_email)||'';
  const cfg=(await lpCfgGet()).funil;
  const rows=await sbJson(`/rest/v1/lp_contatos?id=eq.${encodeURIComponent(String(id))}&select=id,dono,dados,atualizado&limit=2`);
  if(!rows||!rows.length){ const e=new Error('Contato não encontrado (ou sem permissão)'); throw e; }
  if(rows.length>1){ const e=new Error('Mais de um contato com esse id — abra no CRM'); throw e; }
  const row=rows[0]; let dados=row.dados||{}, mudou=false;
  for(const a of (acoes||[])){ const r=lpcAplicar(cfg,dados,a,por); if(r.mudou){ dados=r.dados; mudou=true; } }
  if(!mudou) return {id:row.id,dono:row.dono,dados:row.dados,atualizado:row.atualizado,semMudanca:true};
  if(dados.funil!=='bn') dados=lpcNormContato(dados);
  dados._upd=new Date().toISOString();
  const out=await sbJson(`/rest/v1/lp_contatos?on_conflict=dono,id&select=id,dono,dados,atualizado`,
    {method:'POST',body:{id:String(row.id),dono:row.dono,dados},headers:{Prefer:'resolution=merge-duplicates,return=representation'}});
  const saiu=out&&out[0]?{id:out[0].id,dono:out[0].dono,dados:out[0].dados,atualizado:out[0].atualizado}:{id:row.id,dono:row.dono,dados};
  lpcCacheGravou(saiu); _lpCfgAt=0;   /* cache já traz a linha nova: o catálogo de listas relê sem baixar a tabela */
  return saiu;
}
async function lpSearchAll(q){
  const [contatos,carteira]=await Promise.all([lpcSearch(q),lpSearch(q)]);
  return {contatos,carteira};
}

// espelho de setLeadTask (L1408-1412): data no lead + descrição na timeline (best-effort)
async function setTask(id,dateISO,texto,before){
  const r=await waUpdateLead(id,{data_proxima_acao:dateISO},before);
  if(r.status==='updated' && texto){
    const s=await getSession();
    try{ await sbJson('/rest/v1/lead_events',{method:'POST',body:{lead_id:id,tipo:'tarefa',texto,usuario:(s&&s.usuario)||''},headers:{Prefer:'return=minimal'}}); }catch(_){}
  }
  return r;
}
